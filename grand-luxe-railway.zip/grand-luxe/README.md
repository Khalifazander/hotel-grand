# 🏨 Grand Luxe Hotel — Railway Deployment Guide

## What's in this folder

```
grand-luxe/
├── src/
│   ├── main.jsx          ← React entry point
│   └── App.jsx           ← Full hotel app (1,787 lines)
├── public/
│   ├── manifest.json     ← PWA config (install as app)
│   └── favicon.svg       ← Hotel icon
├── index.html            ← HTML shell
├── package.json          ← Dependencies
├── vite.config.js        ← Build config (Railway-ready)
├── railway.json          ← Railway deploy config
└── .gitignore
```

---

## 🚀 Deploy to Railway in 5 steps

### Step 1 — Install dependencies locally (test first)
```bash
cd grand-luxe
npm install
npm run dev
# Visit http://localhost:5173 — everything should work
```

### Step 2 — Push to GitHub
```bash
git init
git add .
git commit -m "Grand Luxe Hotel app"

# Create a repo on github.com, then:
git remote add origin https://github.com/YOUR_USERNAME/grand-luxe.git
git push -u origin main
```

### Step 3 — Create Railway project
1. Go to **railway.app** → Sign up / Log in (free with GitHub)
2. Click **"New Project"**
3. Select **"Deploy from GitHub repo"**
4. Choose your `grand-luxe` repository
5. Railway auto-detects it as a Node.js app ✅

### Step 4 — Railway builds & deploys automatically
- Railway runs `npm install` then `npm run build` then `npm run start`
- Build takes ~60 seconds
- You'll see live build logs in the Railway dashboard

### Step 5 — Get your live URL
1. In Railway dashboard → click your service
2. Go to **Settings → Networking → Generate Domain**
3. Your app is live at: `https://grand-luxe-XXXX.up.railway.app`

---

## 🌐 Add a custom domain (optional)

In Railway → Settings → Networking → Custom Domain:
```
staff.grandluxehotel.co.ke   →  point CNAME to Railway domain
```

---

## 📱 Install as PWA on staff phones/tablets

Once live, share the URL with staff:
1. Open URL in **Chrome** (Android) or **Safari** (iPhone)
2. Tap browser menu → **"Add to Home Screen"**
3. App installs like a native app — works offline for most features

---

## 🔑 Staff PINs (change these before going live!)

| Name | Role | PIN |
|------|------|-----|
| Alice Njeri | Manager | 1111 |
| Brian Otieno | Waiter | 2222 |
| Carol Wambui | Chef | 3333 |
| David Kamau | Bartender | 4444 |
| Eve Akinyi | Waiter | 5555 |
| Frank Maina | Chef | 6666 |

To change PINs, edit `STAFF_ACCOUNTS` array at the top of `src/App.jsx`.

---

## 💰 Railway Pricing

| Plan | Price | What you get |
|------|-------|-------------|
| **Starter** (free) | $0 | $5 credit/month, sleeps after inactivity |
| **Hobby** | $5/month | Always-on, custom domain, more resources |

For a hotel, **Hobby ($5/month)** is recommended so the app never sleeps.

---

## ⚡ Environment Variables (for future API integrations)

In Railway → Variables tab, add:
```
VITE_MPESA_CONSUMER_KEY=your_key_here
VITE_MPESA_CONSUMER_SECRET=your_secret_here
VITE_WA_PHONE_ID=your_whatsapp_phone_id
VITE_WA_TOKEN=your_whatsapp_token
VITE_SUPABASE_URL=https://xxx.supabase.co
VITE_SUPABASE_ANON_KEY=your_anon_key
```

Railway automatically injects these at build time.

---

## 🛠️ Update the app after changes

```bash
# Make changes to src/App.jsx, then:
git add .
git commit -m "Updated menu prices"
git push

# Railway auto-deploys within 60 seconds ✅
```

---

## 🆘 Troubleshooting

**App won't start on Railway:**
- Check Railway logs for errors
- Make sure `package.json` has `"start": "vite preview --host 0.0.0.0 --port $PORT"`
- Railway requires `$PORT` env variable — already handled in `vite.config.js`

**Blank white screen:**
- Open browser console (F12) and check for errors
- Usually means a missing import — check `src/App.jsx` imports recharts correctly

**Data lost on redeploy:**
- This app uses localStorage which lives in the browser, not the server
- Data is safe across redeployments — it only resets if the user clears browser storage
- For permanent server-side storage, connect Supabase (see DEPLOYMENT_GUIDE.html)
